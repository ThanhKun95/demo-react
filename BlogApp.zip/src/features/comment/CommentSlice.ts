import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Comment, MultipleComments, AddComment, AddCommentDetail } from '~/models';

interface initial {
	comments: Comment[];
	getCommentSuccess: boolean;
	getCommentFailed: boolean;

	updateCommentSuccess: boolean;
	updateCommentFailed: boolean;
}

const initialState: initial = {
	comments: [],
	getCommentSuccess: false,
	getCommentFailed: false,

	updateCommentSuccess: false,
	updateCommentFailed: false,
};

const commentSlice = createSlice({
	name: 'comments',
	initialState,
	reducers: {
		GET_COMMENT: (state, action: PayloadAction<string>) => {},
		GET_COMMENT_SUCCESS: (state, action: PayloadAction<MultipleComments>) => {
			const dataSort = [...action.payload.comments];
			dataSort.sort(function (a, b) {
				const x = new Date(a.createdAt);
				const y = new Date(b.createdAt);
				return x > y ? -1 : x < y ? 1 : 0;
			});
			state.comments = dataSort;
			state.getCommentSuccess = true;
		},
		GET_COMMENT_FAILED: (state) => {
			state.getCommentFailed = true;
		},
		RESET_GET_COMMENT: (state) => {
			state.getCommentFailed = false;
			state.getCommentSuccess = false;
		},

		UPDATE_COMMENT: (state, PayloadAction: PayloadAction<AddComment>) => {},
		UPDATE_COMMENT_SUCCESS: (state, action: PayloadAction<Comment>) => {
			state.comments.unshift(action.payload);
			state.updateCommentSuccess = true;
		},
		UPDATE_COMMENT_FAILED: (state) => {
			state.updateCommentFailed = true;
		},
		UPDATE_COMMENT_RESET: (state) => {
			state.updateCommentSuccess = false;
			state.updateCommentFailed = false;
			state.comments = [];
		},
	},
});

// Actions
export const commentActions = commentSlice.actions;

// Reducer
const commentReducer = commentSlice.reducer;
export default commentReducer;

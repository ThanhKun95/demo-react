import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CreateArticle, UpdateArticle, MultipleArticles } from '~/models';

interface initial {
	articles: any;
	isLoadingSuccess: boolean;
	isLoadingFailed: boolean;

	isCreateSuccess: boolean;
	isCreateFailed: boolean;

	isDeleteSuccess: boolean;
	isDeleteFailed: boolean;

	updateSuccess: boolean;
	updateFailed: boolean;

	authorSuccess: boolean;
}

const initialState: initial = {
	articles: {},

	isLoadingSuccess: false,
	isLoadingFailed: false,

	isCreateSuccess: false,
	isCreateFailed: false,

	isDeleteSuccess: false,
	isDeleteFailed: false,

	updateSuccess: false,
	updateFailed: false,

	authorSuccess: false,
};

const articleSlice = createSlice({
	name: 'articles',
	initialState,
	reducers: {
		GET_ARTICLE: (state) => {},
		GET_ARTICLE_SUCCESS: (state, action: PayloadAction<MultipleArticles>) => {
			state.articles = action.payload;
			state.isLoadingSuccess = true;
		},
		GET_ARTICLE_FAILED: (state) => {
			state.isLoadingFailed = true;
		},
		ARTICLE_RESET: (state) => {
			state.isLoadingFailed = false;
			state.isLoadingSuccess = false;
		},

		GET_ARTICLE_BY_AUTHOR: (state, action: PayloadAction<string>) => {},
		GET_ARTICLE_BY_AUTHOR_SUCCESS: (state) => {
			state.authorSuccess = true;
		},
		GET_ARTICLE_BY_AUTHOR_RESET: (state) => {
			state.authorSuccess = false;
		},

		GET_ARTICLE_BY_SLUG: (state, action: PayloadAction<string>) => {},

		IS_CREATE: (state, action: PayloadAction<CreateArticle>) => {},
		IS_CREATE_SUCCESS: (state) => {
			state.isCreateSuccess = true;
		},
		IS_CREATED_FAILED: (state) => {
			state.isCreateFailed = true;
		},
		RESET_CREATE: (state) => {
			state.isCreateSuccess = false;
			state.isCreateFailed = false;
		},

		IS_DELETE: (state, action: PayloadAction<string>) => {},
		IS_DELETE_SUCCESS: (state) => {
			state.isDeleteSuccess = true;
		},
		IS_DELETE_FAILED: (state) => {
			state.isCreateFailed = true;
		},
		RESET_DELETE: (state) => {
			state.isDeleteSuccess = false;
			state.isCreateFailed = false;
		},

		UPDATE: (state, action: PayloadAction<UpdateArticle>) => {},
		UPDATE_SUCCESS: (state) => {
			state.updateSuccess = true;
		},
		UPDATE_FAILED: (state) => {
			state.updateFailed = true;
		},
		RESET_UPDATE: (state) => {
			state.updateSuccess = false;
			state.updateFailed = false;
		},
	},
});

// Actions
export const articleActions = articleSlice.actions;

// Reducer
const articleReducer = articleSlice.reducer;
export default articleReducer;

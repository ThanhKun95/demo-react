import { PayloadAction } from '@reduxjs/toolkit';
import { call, put, takeLatest } from 'redux-saga/effects';
import { profileApi } from '~/api';
import { Personal } from '~/models';
import { personalActions } from './PersonalSlice';

function* personal(action: PayloadAction<string>) {
	try {
		const response: Personal = yield call(profileApi.getProfile, action.payload);
		if (response) {
			yield put(personalActions.GET_PERSONAL_SUCCESS(response));
		}
	} catch (error) {
		console.log('Error:', error);
		yield put(personalActions.GET_PERSONAL_FAILED());
	}
}

export default function* personalSaga() {
	yield takeLatest(personalActions.GET_PERSONAL.type, personal);
}

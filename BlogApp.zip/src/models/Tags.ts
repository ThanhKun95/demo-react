export interface Tags {
	tags: string[];
}

/* eslint-disable react-hooks/exhaustive-deps */
import SubSidebarProfile from './SubSidebarProfile';
import './Personal.scss';
import { useParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '~/app/hooks';
import Blog from '../Blog';
import { useEffect, useState } from 'react';
import { personalActions } from '~/features/personal/PersonalSlice';
import { commentActions } from '~/features/comment/CommentSlice';
import { articleActions } from '~/features/article/ArticleSlice';
import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';

function Personal() {
	const { auth, personal, articles } = useAppSelector((state) => state);
	const { personalPage } = useParams();
	const [loading, setLoading] = useState(true);
	const dispatch = useAppDispatch();
	useEffect(() => {
		setLoading(true);
		if (personalPage) {
			dispatch(personalActions.GET_PERSONAL(personalPage));
			dispatch(articleActions.GET_ARTICLE_BY_AUTHOR(personalPage));
			dispatch(articleActions.GET_ARTICLE_BY_AUTHOR_RESET());
		}
		return () => {
			dispatch(personalActions.RESET_PERSONAL());
		};
	}, []);
	const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
	const listArticles = articles.articles.articles;
	const { authorSuccess } = articles;

	return (
		<div className="personal-container">
			{auth.isLoggedIn && <SubSidebarProfile />}
			{listArticles && listArticles.length > 0 && authorSuccess ? (
				<Blog articles={listArticles} more="Read more ..." />
			) : (
				<span className="spin-load">
					<Spin indicator={antIcon} />
				</span>
			)}
			{/* <CommentBlog /> */}
		</div>
	);
}

export default Personal;

import { Avatar, Card } from 'antd';
import moment from 'moment';
import { memo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ButtonHeart, Comment } from '../Button';
import { useAppDispatch, useAppSelector } from '~/app/hooks';
import { commentActions } from '~/features/comment/CommentSlice';
import { Comment as CommentIF } from '~/models';
const { Meta } = Card;
function CommentBlog() {
	const navigate = useNavigate();
	const dispatch = useAppDispatch();
	const { slugPage } = useParams();
	const { comments } = useAppSelector((state) => state.comments);

	return (
		<div style={{ width: '100%' }}>
			<ul className="list-comment">
				<li className="comment-item">
					{' '}
					{comments &&
						comments.length > 0 &&
						comments.map((res: CommentIF) => {
							const { id, author, body, createdAt } = res;
							// console.log(res);
							return (
								<div key={id} style={{ marginBottom: 30 }}>
									<div className="user-UserContent">
										<Meta
											style={{ marginTop: '12px' }}
											avatar={
												<span
													className="cursor-pointer"
													onClick={() => {
														navigate(`/article/${author.username}`);
													}}
												>
													<Avatar
														src={
															author.image
																? author.image
																: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
														}
														style={{ width: '32px' }}
													/>
												</span>
											}
											title={
												<span
													className="cursor-pointer"
													onClick={() => {
														navigate(`/article/${author.username}`);
													}}
												>
													{author.username}
												</span>
											}
										/>
										<div>
											<Card
												bordered={false}
												style={{ margin: '12px 12px 12px 48px' }}
											>
												{body}
											</Card>
											<Card
												style={{ width: '100%', border: 0 }}
												actions={[
													<ButtonHeart />,
													<Comment />,
													<div>
														{moment(createdAt).format('DD MMMM YYYY')}
													</div>,
												]}
											></Card>
										</div>
									</div>
								</div>
							);
						})}
				</li>
			</ul>
		</div>
	);
}

export default memo(CommentBlog);

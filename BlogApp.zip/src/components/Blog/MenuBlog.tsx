import { Dropdown, Menu, message, Space } from 'antd';
import { BiDotsHorizontalRounded } from 'react-icons/bi';
import { NavLink } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '~/app/hooks';
import { AiOutlineEdit, AiOutlineDelete, AiFillHeart, AiOutlineHeart } from 'react-icons/ai';
import { RiUserFollowLine, RiUserUnfollowLine } from 'react-icons/ri';
import { articleActions } from '~/features/article/ArticleSlice';
import { useEffect, memo, useState } from 'react';
import { UpdateArticle } from '~/models';

function MenuBlog({ slug, userName }: any) {
	const dispatch = useAppDispatch();
	const { auth, articles } = useAppSelector((state) => state);
	const username = auth.dataAuth?.user?.username;
	const { isDeleteSuccess, isDeleteFailed } = articles;

	// Handle Delete
	useEffect(() => {
		if (isDeleteSuccess) {
			dispatch(articleActions.RESET_DELETE());
			dispatch(articleActions.GET_ARTICLE());
		}
		if (isDeleteFailed) {
			message.success('Delete failed');
		}
	}, [isDeleteSuccess, isDeleteFailed]);
	const handleDelete = () => {
		dispatch(articleActions.IS_DELETE(slug));
	};

	const items1 = [
		{
			label: (
				<NavLink to={`/editor/${slug}`} className="flex-center">
					<AiOutlineEdit /> &nbsp; Edit Article
				</NavLink>
			),
			key: '1',
		},
		{
			label: (
				<div className="flex-center " onClick={handleDelete}>
					<AiOutlineDelete />
					&nbsp; Delete Article
				</div>
			),
			key: '2',
		},
	];
	const items2 = [
		{
			label: (
				<div className="flex-center">
					<RiUserUnfollowLine /> &nbsp; Follow
					{/*<RiUserFollowLine /> &nbsp; Unfollow */}
				</div>
			),
			key: '0',
		},
		{
			label: (
				<div className="flex-center ">
					<AiFillHeart />
					&nbsp; Unfavorite Article
					{/* <AiOutlineHeart/>
					&nbsp; Favorite Article */}
				</div>
			),
			key: '1',
		},
	];
	const items = username === userName ? items1 : items2;
	return (
		<span style={{ margin: '20px 30px' }} className="cursor-pointer">
			<Space direction="vertical">
				<Space wrap>
					<Dropdown
						overlay={<Menu items={items} />}
						placement="bottomRight"
						trigger={['click']}
					>
						<span
							style={{
								width: 46,
								height: 46,
								objectFit: 'cover',
								borderRadius: 99,
							}}
						>
							<BiDotsHorizontalRounded />
						</span>
					</Dropdown>
				</Space>
			</Space>
		</span>
	);
}

export default memo(MenuBlog);

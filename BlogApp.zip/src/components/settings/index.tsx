import React from 'react';
export default function Settings() {
  return (
    <div>
      Setting
    </div>
  )
}
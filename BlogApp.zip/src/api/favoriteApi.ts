import axiosClient from './axiosClient';

const favoriteApi = {
	favoriteArticle: (slug: string) => {
		return axiosClient.post(`articles/${slug}/favorite`);
	},
	unfavoriteArticle: (slug: string) => {
		return axiosClient.delete(`articles/${slug}/favorite`);
	},
};
export default favoriteApi;
